﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textBasedAdv
{
    public class ManaPot : Item
    {        
        public int AmountToRestore { get; set; }

        public ManaPot(int id, string name, string namePlural, int amountToHeal)  :  base(id, name, namePlural)
{
            AmountToRestore = amountToHeal;
        }
    }
}
