﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textBasedAdv
{
    public class Spell : Item
    {
        public int MinimumDamage { get; set; }
        public int MaximumDamage { get; set; }
        public int ManaRequired { get; set; }
        public string SpellName { get; set; }

        public Spell(int id, string name, string namePlural, string spellName, int minimumDamage, int maximumDamage, int manaRequired) : base(id, name, namePlural)
        {
            MinimumDamage = minimumDamage;
            MaximumDamage = maximumDamage;
            ManaRequired = manaRequired;
            SpellName = spellName;
        }
    }
}
