﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using textBasedAdv;

namespace textBasedAdv
{
    public partial class Form1 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect, // x-coordinate of upper-left corner
            int nTopRect, // y-coordinate of upper-left corner
            int nRightRect, // x-coordinate of lower-right corner
            int nBottomRect, // y-coordinate of lower-right corner
            int nWidthEllipse, // height of ellipse
            int nHeightEllipse // width of ellipse
        );

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }

            base.WndProc(ref m);
        }

        private Player _player;
        private Monster _currentMonster;
        bool helmet = false;
        bool fireball = false;
        bool ironchest = false;
        bool rustyleggings = false;



        public Form1()
        {

            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));


            _player = new Player(10, 10, 20, 0, 1, 5, 5);
            MoveTo(World.LocationByID(World.LOCATION_ID_HOME));
            _player.Inventory.Add(new InventoryItem(World.ItemByID(World.ITEM_ID_RUSTY_SWORD), 1));

            lblHP.Text = _player.CurrentHitPoints.ToString();
            lblGold.Text = _player.Gold.ToString();
            lblExp.Text = _player.ExperiencePoints.ToString();
            lblLevel.Text = _player.Level.ToString();
            lblMana.Text = _player.Mana.ToString();

        }

        private void btnNorth_Click(object sender, EventArgs e)
        {
            MoveTo(_player.CurrentLocation.LocationToNorth);
        }

        private void btnEast_Click(object sender, EventArgs e)
        {
            MoveTo(_player.CurrentLocation.LocationToEast);
        }

        private void btnSouth_Click(object sender, EventArgs e)
        {
            MoveTo(_player.CurrentLocation.LocationToSouth);
        }

        private void btnWest_Click(object sender, EventArgs e)
        {
            MoveTo(_player.CurrentLocation.LocationToWest);
        }

        private void MoveTo(Location newLocation)
        {
            // Does the location have any required items
            if (!_player.HasRequiredItemToEnterThisLocation(newLocation))
            {
                rtbMessages.Text += "You must have a " + newLocation.ItemRequiredToEnter.Name + " to enter this location." + Environment.NewLine;
                ScrollToBottomOfMessages();
                return;
            }

            // Update the player's current location
            _player.CurrentLocation = newLocation;

            // Show/hide available movement buttons
            btnNorth.Visible = (newLocation.LocationToNorth != null);
            btnEast.Visible = (newLocation.LocationToEast != null);
            btnSouth.Visible = (newLocation.LocationToSouth != null);
            btnWest.Visible = (newLocation.LocationToWest != null);

            // Display current location name and description
            rtbLocation.Text = newLocation.Name + Environment.NewLine;
            rtbLocation.Text += newLocation.Description + Environment.NewLine;
            rtbLocation.Text += newLocation.LootAvailable + Environment.NewLine;

            // Completely heal the player
            _player.CurrentHitPoints = _player.MaxHitPoints;


            // Update Hit Points in UI
            lblHP.Text = _player.CurrentHitPoints.ToString();


            // Does the location have a quest?
            if (newLocation.QuestAvailableHere != null)
            {
                // See if the player already has the quest, and if they've completed it
                bool playerAlreadyHasQuest = _player.HasThisQuest(newLocation.QuestAvailableHere);
                bool playerAlreadyCompletedQuest = _player.CompletedThisQuest(newLocation.QuestAvailableHere);

                // See if the player already has the quest
                if (playerAlreadyHasQuest)
                {
                    // If the player has not completed the quest yet
                    if (!playerAlreadyCompletedQuest)
                    {
                        // See if the player has all the items needed to complete the quest
                        bool playerHasAllItemsToCompleteQuest = _player.HasAllQuestCompletionItems(newLocation.QuestAvailableHere);

                        // The player has all items required to complete the quest
                        if (playerHasAllItemsToCompleteQuest)
                        {
                            // Display message
                            rtbMessages.Text += Environment.NewLine;
                            rtbMessages.Text += "You complete the '" + newLocation.QuestAvailableHere.Name + "' quest." + Environment.NewLine;
                            ScrollToBottomOfMessages();

                            // Remove quest items from inventory
                            _player.RemoveQuestCompletionItems(newLocation.QuestAvailableHere);

                            // Give quest rewards
                            rtbMessages.Text += "You receive: " + Environment.NewLine;
                            rtbMessages.Text += newLocation.QuestAvailableHere.RewardExperiencePoints.ToString() + " experience points" + Environment.NewLine;
                            rtbMessages.Text += newLocation.QuestAvailableHere.RewardGold.ToString() + " gold" + Environment.NewLine;
                            rtbMessages.Text += newLocation.QuestAvailableHere.RewardItem.Name + Environment.NewLine;
                            rtbMessages.Text += Environment.NewLine;
                            ScrollToBottomOfMessages();

                            _player.ExperiencePoints += newLocation.QuestAvailableHere.RewardExperiencePoints;
                            _player.Gold += newLocation.QuestAvailableHere.RewardGold;

                            // Add the reward item to the player's inventory
                            _player.AddItemToInventory(newLocation.QuestAvailableHere.RewardItem);

                            // Mark the quest as completed
                            _player.MarkQuestCompleted(newLocation.QuestAvailableHere);
                        }
                    }
                }
                else
                {
                    // The player does not already have the quest

                    // Display the messages
                    rtbMessages.Text += "You receive the " + newLocation.QuestAvailableHere.Name + " quest." + Environment.NewLine;
                    rtbMessages.Text += newLocation.QuestAvailableHere.Description + Environment.NewLine;
                    rtbMessages.Text += "To complete it, return with:" + Environment.NewLine;
                    ScrollToBottomOfMessages();

                    foreach (QuestCompletionItem qci in newLocation.QuestAvailableHere.QuestCompletionItems)
                    {
                        if (qci.Quantity == 1)
                        {
                            rtbMessages.Text += qci.Quantity.ToString() + " " + qci.Details.Name + Environment.NewLine;
                            ScrollToBottomOfMessages();

                        }
                        else
                        {
                            rtbMessages.Text += qci.Quantity.ToString() + " " + qci.Details.NamePlural + Environment.NewLine;
                            ScrollToBottomOfMessages();
                        }
                    }
                    rtbMessages.Text += Environment.NewLine;
                    ScrollToBottomOfMessages();

                    // Add the quest to the player's quest list
                    _player.Quests.Add(new PlayerQuest(newLocation.QuestAvailableHere));
                }
            }

            // Does the location have a monster?
            if (newLocation.MonsterLivingHere != null)
            {
                rtbMessages.Text += "You see a " + newLocation.MonsterLivingHere.Name + Environment.NewLine;
                ScrollToBottomOfMessages();
                // Make a new monster, using the values from the standard monster in the World.Monster list
                Monster standardMonster = World.MonsterByID(newLocation.MonsterLivingHere.ID);

                _currentMonster = new Monster(standardMonster.ID, standardMonster.Name, standardMonster.MaximumDamage,
                    standardMonster.RewardExperiencePoints, standardMonster.RewardGold, standardMonster.CurrentHitPoints, standardMonster.MaxHitPoints);

                foreach (LootItem lootItem in standardMonster.LootTable)
                {
                    _currentMonster.LootTable.Add(lootItem);
                }

                cboWeapons.Visible = true;
                cboPotions.Visible = true;
                cboManaPots.Visible = true;
                cboSpell.Visible = true;
                btnUseSpell.Visible = true;
                btnUseWeapon.Visible = true;
                btnUsePotion.Visible = true;
                btnUseManaPot.Visible = true;

            }
            else
            {
                _currentMonster = null;

                cboWeapons.Visible = false;
                cboPotions.Visible = false;
                cboManaPots.Visible = false;
                cboSpell.Visible = false;
                btnUseSpell.Visible = false;
                btnUseWeapon.Visible = false;
                btnUsePotion.Visible = false;
                btnUseManaPot.Visible = false;
            }

            // Refresh player's inventory list
            UpdateInventoryListInUI();

            // Refresh player's quest list
            UpdateQuestListInUI();

            // Refresh player's weapons combobox
            UpdateWeaponListInUI();

            // Refresh player's potions combobox
            UpdatePotionListInUI();

            // Refresh player's spell combobox
            UpdateSpellListInUI();
        }

        private void UpdateInventoryListInUI()
        {
            dgvInventory.RowHeadersVisible = false;

            dgvInventory.ColumnCount = 2;
            dgvInventory.Columns[0].Name = "Name";
            dgvInventory.Columns[0].Width = 197;
            dgvInventory.Columns[1].Name = "Quantity";

            dgvInventory.Rows.Clear();

            foreach (InventoryItem inventoryItem in _player.Inventory)
            {
                if (inventoryItem.Quantity > 0)
                {
                    dgvInventory.Rows.Add(new[] { inventoryItem.Details.Name, inventoryItem.Quantity.ToString() });
                }
            }
        }

        private void UpdateQuestListInUI()
        {
            dgvQuests.RowHeadersVisible = false;

            dgvQuests.ColumnCount = 2;
            dgvQuests.Columns[0].Name = "Name";
            dgvQuests.Columns[0].Width = 197;
            dgvQuests.Columns[1].Name = "Done?";

            dgvQuests.Rows.Clear();

            foreach (PlayerQuest playerQuest in _player.Quests)
            {
                dgvQuests.Rows.Add(new[] { playerQuest.Details.Name, playerQuest.IsCompleted.ToString() });
            }
        }

        private void UpdateWeaponListInUI()
        {
            List<Weapon> weapons = new List<Weapon>();

            foreach (InventoryItem inventoryItem in _player.Inventory)
            {
                if (inventoryItem.Details is Weapon)
                {
                    if (inventoryItem.Quantity > 0)
                    {
                        weapons.Add((Weapon)inventoryItem.Details);
                    }
                }
            }

            if (weapons.Count == 0)
            {
                // The player doesn't have any weapons, so hide the weapon combobox and "Use" button
                cboWeapons.Visible = false;
                btnUseWeapon.Visible = false;
            }
            else
            {
                cboWeapons.DataSource = weapons;
                cboWeapons.DisplayMember = "Name";
                cboWeapons.ValueMember = "ID";

                cboWeapons.SelectedIndex = 0;
            }
        }

        private void UpdatePotionListInUI()
        {
            List<HealingPotion> healingPotions = new List<HealingPotion>();

            foreach (InventoryItem inventoryItem in _player.Inventory)
            {
                if (inventoryItem.Details is HealingPotion)
                {
                    if (inventoryItem.Quantity > 0)
                    {
                        healingPotions.Add((HealingPotion)inventoryItem.Details);
                    }
                }
            }

            List<ManaPot> manaPotions = new List<ManaPot>();

            foreach (InventoryItem inventoryItem in _player.Inventory)
            {
                if (inventoryItem.Details is ManaPot)
                {
                    if (inventoryItem.Quantity > 0)
                    {
                        manaPotions.Add((ManaPot)inventoryItem.Details);
                    }
                }
            }

            if (healingPotions.Count == 0)
            {
                // The player doesn't have any potions, so hide the potion combobox and "Use" button
                cboPotions.Visible = false;
                btnUsePotion.Visible = false;
            }
            else if (healingPotions.Count != 0)
            {
                cboPotions.DataSource = healingPotions;
                cboPotions.DisplayMember = "Name";
                cboPotions.ValueMember = "ID";

                cboPotions.SelectedIndex = 0;
            }
            if (manaPotions.Count != 0)
            {
                cboManaPots.DataSource = manaPotions;
                cboManaPots.DisplayMember = "Name";
                cboManaPots.ValueMember = "ID";

                cboManaPots.SelectedIndex = 0;
            }
            if (manaPotions.Count == 0)
            {
                cboManaPots.Visible = false;
                btnUseManaPot.Visible = false;
            }
        }

        private void UpdateSpellListInUI()
        {
            List<Spell> spells = new List<Spell>();

            foreach (InventoryItem inventoryItem in _player.Inventory)
            {
                if (inventoryItem.Details is Spell)
                {
                    if (inventoryItem.Quantity > 0)
                    {
                        spells.Add((Spell)inventoryItem.Details);
                    }
                }
            }

            if (spells.Count == 0)
            {
                // The player doesn't have any weapons, so hide the weapon combobox and "Use" button
                cboSpell.Visible = false;
                btnUseSpell.Visible = false;
            }
            else
            {
                cboSpell.DataSource = spells;
                cboSpell.DisplayMember = "SpellName";
                cboSpell.ValueMember = "ID";

                cboSpell.SelectedIndex = 0;
            }
        }

        private void btnUseWeapon_Click(object sender, EventArgs e)
        {
            // Get the currently selected weapon from the cboWeapons ComboBox
            Weapon currentWeapon = (Weapon)cboWeapons.SelectedItem;

            // Determine the amount of damage to do to the monster
            int damageToMonster = RandomNumberGenerator.NumberBetween(currentWeapon.MinimumDamage, currentWeapon.MaximumDamage);

            // Apply the damage to the monster's CurrentHitPoints
            _currentMonster.CurrentHitPoints = _currentMonster.CurrentHitPoints - damageToMonster;

            // Display message
            rtbMessages.Text += "You hit the " + _currentMonster.Name + " for " + damageToMonster.ToString() + " points." + Environment.NewLine;
            ScrollToBottomOfMessages();

            // Check if the monster is dead
            if (_currentMonster.CurrentHitPoints <= 0)
            {
                // Monster is dead
                rtbMessages.Text += Environment.NewLine;
                rtbMessages.Text += "You defeated the " + _currentMonster.Name + Environment.NewLine;
                ScrollToBottomOfMessages();

                // Give player experience points for killing the monster
                _player.ExperiencePoints += _currentMonster.RewardExperiencePoints;
                rtbMessages.Text += "You receive " + _currentMonster.RewardExperiencePoints.ToString() + " experience points" + Environment.NewLine;
                ScrollToBottomOfMessages();

                // Give player gold for killing the monster 
                _player.Gold += _currentMonster.RewardGold;
                rtbMessages.Text += "You receive " + _currentMonster.RewardGold.ToString() + " gold" + Environment.NewLine;

                // Get random loot items from the monster
                List<InventoryItem> lootedItems = new List<InventoryItem>();

                // Add items to the lootedItems list, comparing a random number to the drop percentage
                foreach (LootItem lootItem in _currentMonster.LootTable)
                {
                    if (RandomNumberGenerator.NumberBetween(1, 100) <= lootItem.DropPercentage)
                    {
                        lootedItems.Add(new InventoryItem(lootItem.Details, 1));
                    }
                }

                // If no items were randomly selected, then add the default loot item(s).
                if (lootedItems.Count == 0)
                {
                    foreach (LootItem lootItem in _currentMonster.LootTable)
                    {
                        if (lootItem.IsDefaultItem)
                        {
                            lootedItems.Add(new InventoryItem(lootItem.Details, 1));
                        }
                    }
                }

                // Add the looted items to the player's inventory
                foreach (InventoryItem inventoryItem in lootedItems)
                {
                    _player.AddItemToInventory(inventoryItem.Details);

                    if (inventoryItem.Quantity == 1)
                    {
                        rtbMessages.Text += "You loot " + inventoryItem.Quantity.ToString() + " " + inventoryItem.Details.Name + Environment.NewLine;
                        ScrollToBottomOfMessages();
                    }
                    else
                    {
                        rtbMessages.Text += "You loot " + inventoryItem.Quantity.ToString() + " " + inventoryItem.Details.NamePlural + Environment.NewLine;
                        ScrollToBottomOfMessages();
                    }
                }

                // Refresh player information and inventory controls
                lblHP.Text = _player.CurrentHitPoints.ToString();
                lblGold.Text = _player.Gold.ToString();
                lblExp.Text = _player.ExperiencePoints.ToString();
                lblLevel.Text = _player.Level.ToString();

                UpdateInventoryListInUI();
                UpdateWeaponListInUI();
                UpdatePotionListInUI();

                // Add a blank line to the messages box, just for appearance.
                rtbMessages.Text += Environment.NewLine;
                ScrollToBottomOfMessages();

                // Move player to current location (to heal player and create a new monster to fight)
                MoveTo(_player.CurrentLocation);



                foreach (InventoryItem inventoryItem in _player.Inventory)
                {
                    if (helmet != true)
                    {
                        if (inventoryItem.Details.Name is "Bucket helmet")
                        {
                            if (inventoryItem.Quantity > 0)
                            {
                                _player.MaxHitPoints = _player.MaxHitPoints + 5;
                                helmet = true;
                            }
                        }
                    }
                }

                foreach (InventoryItem inventoryItem in _player.Inventory)
                {
                    if (ironchest != true)
                    {
                        if (inventoryItem.Details.Name is "Iron chestplate")
                        {
                            if (inventoryItem.Quantity > 0)
                            {
                                _player.MaxHitPoints = _player.MaxHitPoints + 5;
                                ironchest = true;
                            }
                        }
                    }
                }

                foreach (InventoryItem inventoryItem in _player.Inventory)
                {
                    if (rustyleggings != true)
                    {
                        if (inventoryItem.Details.Name is "Rusty leggings")
                        {
                            if (inventoryItem.Quantity > 0)
                            {
                                _player.MaxHitPoints = _player.MaxHitPoints + 5;
                                rustyleggings = true;
                            }
                        }
                    }
                }

            }
            else
            {
                // Monster is still alive

                // Determine the amount of damage the monster does to the player
                int damageToPlayer = RandomNumberGenerator.NumberBetween(0, _currentMonster.MaximumDamage);

                // Display message
                rtbMessages.Text += "The " + _currentMonster.Name + " did " + damageToPlayer.ToString() + " points of damage." + Environment.NewLine;
                ScrollToBottomOfMessages();

                // Subtract damage from player
                _player.CurrentHitPoints -= damageToPlayer;

                // Refresh player data in UI
                lblHP.Text = _player.CurrentHitPoints.ToString();

                if (_player.CurrentHitPoints <= 0)
                {
                    // Display message
                    rtbMessages.Text += "The " + _currentMonster.Name + " killed you." + Environment.NewLine;

                    // Move player to "Home"
                    MoveTo(World.LocationByID(World.LOCATION_ID_HOME));

                    ScrollToBottomOfMessages();
                }
            }
        }

        private void btnUsePotion_Click(object sender, EventArgs e)
        {
            // Get the currently selected potion from the combobox
            HealingPotion potion = (HealingPotion)cboPotions.SelectedItem;


            // Add healing amount to the player's current hit points
            _player.CurrentHitPoints = (_player.CurrentHitPoints + potion.AmountToHeal);


            // CurrentHitPoints cannot exceed player's MaximumHitPoints
            if (_player.CurrentHitPoints > _player.MaxHitPoints)
            {
                _player.CurrentHitPoints = _player.MaxHitPoints;
            }


            // Remove the potion from the player's inventory
            foreach (InventoryItem ii in _player.Inventory)
            {
                if (ii.Details.ID == potion.ID)
                {
                    ii.Quantity--;
                    break;
                }
            }

            // Display message
            rtbMessages.Text += "You drink a " + potion.Name + Environment.NewLine;
            ScrollToBottomOfMessages();


            // Refresh player data in UI
            lblHP.Text = _player.CurrentHitPoints.ToString();
            UpdateInventoryListInUI();
            UpdatePotionListInUI();
        }

        private void ScrollToBottomOfMessages()
        {
            foreach (InventoryItem inventoryItem in _player.Inventory)
            {
                if (helmet != true)
                {
                    if (inventoryItem.Details.Name is "Bucket helmet")
                    {
                        if (inventoryItem.Quantity > 0)
                        {
                            _player.MaxHitPoints = _player.MaxHitPoints + 5;
                            rtbMessages.Text += Environment.NewLine;
                            rtbMessages.Text += "You found a bucket helmet on the rat. You equip it, increasing your HP by 5!" + Environment.NewLine;
                            helmet = true;
                        }
                    }
                }
                if (fireball != true)
                {
                    if (inventoryItem.Details.Name is "Fireball tome")
                    {
                        if (inventoryItem.Quantity > 0)
                        {
                            rtbMessages.Text += Environment.NewLine;
                            rtbMessages.Text += "You received a fireball tome. After studying the pages, you have access to the fireball spell!" + Environment.NewLine;
                            fireball = true;
                        }
                    }
                }
                if (ironchest != true)
                {
                    if (inventoryItem.Details.Name is "Iron chestplate")
                    {
                        if (inventoryItem.Quantity > 0)
                        {
                            _player.MaxHitPoints = _player.MaxHitPoints + 15;
                            rtbMessages.Text += Environment.NewLine;
                            rtbMessages.Text += "You found an iron chestplate! You equip it, increasing your HP by 15!" + Environment.NewLine;
                            ironchest = true;
                        }
                    }
                }
                if (rustyleggings != true)
                {
                    if (inventoryItem.Details.Name is "Rusty leggings")
                    {
                        if (inventoryItem.Quantity > 0)
                        {
                            _player.MaxHitPoints = _player.MaxHitPoints + 10;
                            rtbMessages.Text += Environment.NewLine;
                            rtbMessages.Text += "You found a pair of rusty leggings! You equip them, increasing your HP by 10!" + Environment.NewLine;
                            rustyleggings = true;
                        }
                    }
                }
            }

            rtbMessages.SelectionStart = rtbMessages.Text.Length;
            rtbMessages.ScrollToCaret();
        }

        private void btnUseManaPot_Click(object sender, EventArgs e)
        {
            // Get the currently selected potion from the combobox
            ManaPot potion = (ManaPot)cboManaPots.SelectedItem;


            // Add healing amount to the player's current hit points
            _player.Mana = (_player.Mana + potion.AmountToRestore);


            // CurrentHitPoints cannot exceed player's MaximumHitPoints
            if (_player.Mana > _player.MaxMana)
            {
                _player.Mana = _player.MaxMana;
            }


            // Remove the potion from the player's inventory
            foreach (InventoryItem ii in _player.Inventory)
            {
                if (ii.Details.ID == potion.ID)
                {
                    ii.Quantity--;
                    break;
                }
            }

            // Display message
            rtbMessages.Text += "You drink a " + potion.Name + Environment.NewLine;
            ScrollToBottomOfMessages();

            // Refresh player data in UI
            lblMana.Text = _player.Mana.ToString();
            UpdateInventoryListInUI();
            UpdatePotionListInUI();

        }

        private void btnUseSpell_Click(object sender, EventArgs e)
        {
            // Get the currently selected spell from the cboSpell ComboBox
            Spell currentSpell = (Spell)cboSpell.SelectedItem;

            // Determine the amount of damage to do to the monster
            int damageToMonster = RandomNumberGenerator.NumberBetween(currentSpell.MinimumDamage, currentSpell.MaximumDamage);

            if (_player.Mana >= currentSpell.ManaRequired)
            {
                // Apply the damage to the monster's CurrentHitPoints
                _currentMonster.CurrentHitPoints = _currentMonster.CurrentHitPoints - damageToMonster;

                // Display message
                rtbMessages.Text += "You hit the " + _currentMonster.Name + " for " + damageToMonster.ToString() + " points with the " + currentSpell.SpellName + " spell." + Environment.NewLine;
                ScrollToBottomOfMessages();

                // Removes the mana required for the spell from the players current mana
                _player.Mana = _player.Mana - currentSpell.ManaRequired;
                lblMana.Text = _player.Mana.ToString();
                
                // See if using leech life so we can steal the HP
                if (currentSpell.Name is "Leech life tome")
                {
                    if ((_player.CurrentHitPoints + damageToMonster) > _player.MaxHitPoints)
                    {
                        rtbMessages.Text += "You stole " + Math.Abs(_player.MaxHitPoints - _player.CurrentHitPoints).ToString() + "HP from the " + _currentMonster.Name + Environment.NewLine;
                        _player.CurrentHitPoints = _player.MaxHitPoints;
                        
                    }
                    else
                    {
                        _player.CurrentHitPoints += damageToMonster;
                        rtbMessages.Text += "You stole " + damageToMonster.ToString() + "HP from the " + _currentMonster.Name + Environment.NewLine;
                    }


                    lblHP.Text = _player.CurrentHitPoints.ToString();
                }

                // Check if the monster is dead
                if (_currentMonster.CurrentHitPoints <= 0)
                {
                    // Monster is dead
                    rtbMessages.Text += Environment.NewLine;
                    rtbMessages.Text += "You defeated the " + _currentMonster.Name + Environment.NewLine;
                    ScrollToBottomOfMessages();

                    // Give player experience points for killing the monster
                    _player.ExperiencePoints += _currentMonster.RewardExperiencePoints;
                    rtbMessages.Text += "You receive " + _currentMonster.RewardExperiencePoints.ToString() + " experience points" + Environment.NewLine;
                    ScrollToBottomOfMessages();

                    // Give player gold for killing the monster 
                    _player.Gold += _currentMonster.RewardGold;
                    rtbMessages.Text += "You receive " + _currentMonster.RewardGold.ToString() + " gold" + Environment.NewLine;

                    // Get random loot items from the monster
                    List<InventoryItem> lootedItems = new List<InventoryItem>();

                    // Add items to the lootedItems list, comparing a random number to the drop percentage
                    foreach (LootItem lootItem in _currentMonster.LootTable)
                    {
                        if (RandomNumberGenerator.NumberBetween(1, 100) <= lootItem.DropPercentage)
                        {
                            lootedItems.Add(new InventoryItem(lootItem.Details, 1));
                        }
                    }

                    // If no items were randomly selected, then add the default loot item(s).
                    if (lootedItems.Count == 0)
                    {
                        foreach (LootItem lootItem in _currentMonster.LootTable)
                        {
                            if (lootItem.IsDefaultItem)
                            {
                                lootedItems.Add(new InventoryItem(lootItem.Details, 1));
                            }
                        }
                    }

                    // Add the looted items to the player's inventory
                    foreach (InventoryItem inventoryItem in lootedItems)
                    {
                        _player.AddItemToInventory(inventoryItem.Details);

                        if (inventoryItem.Quantity == 1)
                        {
                            rtbMessages.Text += "You loot " + inventoryItem.Quantity.ToString() + " " + inventoryItem.Details.Name + Environment.NewLine;
                            ScrollToBottomOfMessages();
                        }
                        else
                        {
                            rtbMessages.Text += "You loot " + inventoryItem.Quantity.ToString() + " " + inventoryItem.Details.NamePlural + Environment.NewLine;
                            ScrollToBottomOfMessages();
                        }
                    }

                    // Refresh player information and inventory controls
                    lblHP.Text = _player.CurrentHitPoints.ToString();
                    lblGold.Text = _player.Gold.ToString();
                    lblExp.Text = _player.ExperiencePoints.ToString();
                    lblLevel.Text = _player.Level.ToString();
                    lblMana.Text = _player.Mana.ToString();

                    UpdateInventoryListInUI();
                    UpdateWeaponListInUI();
                    UpdatePotionListInUI();
                    UpdateSpellListInUI();

                    // Add a blank line to the messages box, just for appearance.
                    rtbMessages.Text += Environment.NewLine;
                    ScrollToBottomOfMessages();

                    // Move player to current location (to heal player and create a new monster to fight)
                    MoveTo(_player.CurrentLocation);
                }


                else
                {
                    // Monster is still alive

                    // Determine the amount of damage the monster does to the player
                    int damageToPlayer = RandomNumberGenerator.NumberBetween(0, _currentMonster.MaximumDamage);

                    // Display message
                    rtbMessages.Text += "The " + _currentMonster.Name + " did " + damageToPlayer.ToString() + " points of damage." + Environment.NewLine;
                    ScrollToBottomOfMessages();

                    // Subtract damage from player
                    _player.CurrentHitPoints -= damageToPlayer;

                    // Refresh player data in UI
                    lblHP.Text = _player.CurrentHitPoints.ToString();

                    if (_player.CurrentHitPoints <= 0)
                    {
                        // Display message
                        rtbMessages.Text += "The " + _currentMonster.Name + " killed you." + Environment.NewLine;

                        // Move player to "Home"
                        MoveTo(World.LocationByID(World.LOCATION_ID_HOME));

                        ScrollToBottomOfMessages();
                    }



                }




            }

            else
            {
                rtbMessages.Text += Environment.NewLine + "You don't have enough mana!" + Environment.NewLine;
                ScrollToBottomOfMessages();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form.ActiveForm.Close();
        }
    }
}
