﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textBasedAdv
{
    public class Armour : Item
    {
        public int ExtraHit { get; set; }

        public Armour(int id, string name, string namePlural, int extraHP) : base(id, name, namePlural)
        {
            ExtraHit = extraHP;
        }
    }
}
