﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textBasedAdv
{
    public static class World
    {
        public static readonly List<Item> Items = new List<Item>();
        public static readonly List<Monster> Monsters = new List<Monster>();
        public static readonly List<Quest> Quests = new List<Quest>();
        public static readonly List<Location> Locations = new List<Location>();

        public const int ITEM_ID_RUSTY_SWORD = 1;
        public const int ITEM_ID_RAT_TAIL = 2;
        public const int ITEM_ID_PIECE_OF_FUR = 3;
        public const int ITEM_ID_SNAKE_FANG = 4;
        public const int ITEM_ID_SNAKESKIN = 5;
        public const int ITEM_ID_CLUB = 6;
        public const int ITEM_ID_HEALING_POTION = 7;
        public const int ITEM_ID_SPIDER_FANG = 8;
        public const int ITEM_ID_SPIDER_SILK = 9;
        public const int ITEM_ID_ADVENTURER_PASS = 10;
        public const int ITEM_ID_MANA_POT = 11;
        public const int ITEM_ID_BUCKET_HELMET = 12;
        public const int ITEM_ID_FIREBALL = 13;
        public const int ITEM_ID_GUARD_HELMET = 14;
        public const int ITEM_ID_IRON_CHESTPLATE = 15;
        public const int ITEM_ID_LEECH_LIFE = 16;
        public const int ITEM_ID_RUSTY_LEGGINGS = 17;
        public const int ITEM_ID_BONE = 18;
        public const int ITEM_ID_DRAIN_KEY = 19;

        public const int MONSTER_ID_RAT = 1;
        public const int MONSTER_ID_SNAKE = 2;
        public const int MONSTER_ID_GIANT_SPIDER = 3;
        public const int MONSTER_ID_GUARD = 4;
        public const int MONSTER_ID_SKELETON = 5;

        public const int QUEST_ID_CLEAR_ALCHEMIST_GARDEN = 1;
        public const int QUEST_ID_CLEAR_FARMERS_FIELD = 2;
        public const int QUEST_ID_CLEAR_GUARD_TOWER = 3;
        public const int QUEST_ID_CLEAR_CEMETERY = 4;
        public const int QUEST_ID_CLEAR_BASEMENT = 5;
        
        public const int LOCATION_ID_HOME = 1;
        public const int LOCATION_ID_TOWN_SQUARE = 2;
        public const int LOCATION_ID_GUARD_POST = 3;
        public const int LOCATION_ID_ALCHEMIST_HUT = 4;
        public const int LOCATION_ID_ALCHEMISTS_GARDEN = 5;
        public const int LOCATION_ID_FARMHOUSE = 6;
        public const int LOCATION_ID_FARM_FIELD = 7;
        public const int LOCATION_ID_BRIDGE = 8;
        public const int LOCATION_ID_SPIDER_FIELD = 9;
        public const int LOCATION_ID_CEMETERY = 10;
        public const int LOCATION_ID_NECROMANCERS_HUT = 11;
        public const int LOCATION_ID_BASEMENT = 12;
        public const int LOCATION_ID_DRAINS = 13;


        static World()
        {
            PopulateItems();
            PopulateMonsters();
            PopulateQuests();
            PopulateLocations();
        }

        private static void PopulateItems()
        {
            Items.Add(new Weapon(ITEM_ID_RUSTY_SWORD, "Rusty sword", "Rusty swords", 0, 5));
            Items.Add(new Item(ITEM_ID_RAT_TAIL, "Rat tail", "Rat tails"));
            Items.Add(new Item(ITEM_ID_PIECE_OF_FUR, "Piece of fur", "Pieces of fur"));
            Items.Add(new Item(ITEM_ID_SNAKE_FANG, "Snake fang", "Snake fangs"));
            Items.Add(new Item(ITEM_ID_SNAKESKIN, "Snakeskin", "Snakeskins"));
            Items.Add(new Weapon(ITEM_ID_CLUB, "Club", "Clubs", 3, 10));
            Items.Add(new HealingPotion(ITEM_ID_HEALING_POTION, "Healing potion", "Healing potions", 10));
            Items.Add(new Item(ITEM_ID_SPIDER_FANG, "Spider fang", "Spider fangs"));
            Items.Add(new Item(ITEM_ID_SPIDER_SILK, "Spider silk", "Spider silks"));
            Items.Add(new Item(ITEM_ID_ADVENTURER_PASS, "Adventurer pass", "Adventurer passes"));
            Items.Add(new ManaPot(ITEM_ID_MANA_POT, "Mana potion", "Mana potions", 5));
            Items.Add(new Armour(ITEM_ID_BUCKET_HELMET, "Bucket helmet", "Bucket helmets", 5));
            Items.Add(new Spell(ITEM_ID_FIREBALL, "Fireball tome", "Fireball tomes", "Fireball", 6, 7, 3));
            Items.Add(new Item(ITEM_ID_GUARD_HELMET, "Guard's helmet", "Guard's helmets"));
            Items.Add(new Armour(ITEM_ID_IRON_CHESTPLATE, "Iron chestplate", "Iron chestplates", 15));
            Items.Add(new Armour(ITEM_ID_RUSTY_LEGGINGS, "Rusty leggings", "Rusty leggings", 10));
            Items.Add(new Item(ITEM_ID_BONE, "Bone", "Bones"));
            Items.Add(new Spell(ITEM_ID_LEECH_LIFE, "Leech life tome", "Leech life tomes", "Leech life", 1, 7, 2));
            Items.Add(new Item(ITEM_ID_DRAIN_KEY, "Drain key", "Drain keys"));
        }

        private static void PopulateMonsters()
        {
            Monster rat = new Monster(MONSTER_ID_RAT, "Rat", 3, 3, 5, 10, 10);
            rat.LootTable.Add(new LootItem(ItemByID(ITEM_ID_RAT_TAIL), 100, true));
            rat.LootTable.Add(new LootItem(ItemByID(ITEM_ID_PIECE_OF_FUR), 25, false));
            rat.LootTable.Add(new LootItem(ItemByID(ITEM_ID_BUCKET_HELMET), 1, false));

            Monster snake = new Monster(MONSTER_ID_SNAKE, "Snake", 3, 10, 10, 17, 17);
            snake.LootTable.Add(new LootItem(ItemByID(ITEM_ID_SNAKE_FANG), 100, true));
            snake.LootTable.Add(new LootItem(ItemByID(ITEM_ID_SNAKESKIN), 25, false));

            Monster giantSpider = new Monster(MONSTER_ID_GIANT_SPIDER, "GIANT SPIDER! IT'S A BOSS!", 20, 5, 500, 100, 100);
            giantSpider.LootTable.Add(new LootItem(ItemByID(ITEM_ID_SPIDER_FANG), 100, true));
            giantSpider.LootTable.Add(new LootItem(ItemByID(ITEM_ID_SPIDER_SILK), 100, false));

            Monster guard = new Monster(MONSTER_ID_GUARD, "Guard", 5, 20, 75, 20, 20);
            guard.LootTable.Add(new LootItem(ItemByID(ITEM_ID_GUARD_HELMET), 100, true));
            guard.LootTable.Add(new LootItem(ItemByID(ITEM_ID_MANA_POT), 50, false));
            guard.LootTable.Add(new LootItem(ItemByID(ITEM_ID_CLUB), 10, false));
            guard.LootTable.Add(new LootItem(ItemByID(ITEM_ID_IRON_CHESTPLATE), 5, false));

            Monster skeleton = new Monster(MONSTER_ID_SKELETON, "Skeleton", 4, 15, 50, 17, 17);
            skeleton.LootTable.Add(new LootItem(ItemByID(ITEM_ID_BONE), 50, true));
            skeleton.LootTable.Add(new LootItem(ItemByID(ITEM_ID_RUSTY_LEGGINGS), 10, false));
           
            Monsters.Add(guard);
            Monsters.Add(rat);
            Monsters.Add(snake);
            Monsters.Add(giantSpider);
            Monsters.Add(skeleton);
        }

        private static void PopulateQuests()
        {
            Quest clearAlchemistGarden =
                new Quest(
                    QUEST_ID_CLEAR_ALCHEMIST_GARDEN,
                    "Not just weeds",
                    "Kill rats in the alchemist's garden and bring back 3 rat tails. You will receive a healing potion and 10 gold pieces.", 20, 10);

            clearAlchemistGarden.QuestCompletionItems.Add(new QuestCompletionItem(ItemByID(ITEM_ID_RAT_TAIL), 3));
            clearAlchemistGarden.RewardItem = ItemByID(ITEM_ID_HEALING_POTION);

            Quest clearGuardTower =
                new Quest(
                    QUEST_ID_CLEAR_GUARD_TOWER,
                    "Guard tower massacre",
                    "Kill a guard in the guard tower to the east. Bring back his helmet as proof and we'll see about your reward.", 100, 100);
        
            clearGuardTower.QuestCompletionItems.Add(new QuestCompletionItem(ItemByID(ITEM_ID_GUARD_HELMET), 1));
            clearGuardTower.RewardItem = ItemByID(ITEM_ID_FIREBALL);

            Quest clearFarmersField =
                new Quest(
                    QUEST_ID_CLEAR_FARMERS_FIELD,
                    "Snakes! Why did it have to be snakes?",
                    "Kill snakes in the farmer's field and bring back 3 snake fangs. You will receive an adventurer's pass and 20 gold pieces.", 20, 20);

            clearFarmersField.QuestCompletionItems.Add(new QuestCompletionItem(ItemByID(ITEM_ID_SNAKE_FANG), 3));
            clearFarmersField.RewardItem = ItemByID(ITEM_ID_ADVENTURER_PASS);

            Quest clearCemetery =
                new Quest(
                    QUEST_ID_CLEAR_CEMETERY,
                    "Spooky scary skeletons",
                    "Kill skeletons until you can bring back 5 bones. I'll make sure you get a reward.", 50, 100);

            clearCemetery.QuestCompletionItems.Add(new QuestCompletionItem(ItemByID(ITEM_ID_BONE), 5));
            clearCemetery.RewardItem = ItemByID(ITEM_ID_LEECH_LIFE);

            Quest clearBasement =
                new Quest(
                    QUEST_ID_CLEAR_BASEMENT,
                    "Basement banter",
                    "Kill 50 rats. Then I can access the drains.", 20, 50);

            clearBasement.QuestCompletionItems.Add(new QuestCompletionItem(ItemByID(ITEM_ID_RAT_TAIL), 50));
            clearBasement.RewardItem = ItemByID(ITEM_ID_DRAIN_KEY);

            Quests.Add(clearGuardTower);
            Quests.Add(clearAlchemistGarden);
            Quests.Add(clearFarmersField);
            Quests.Add(clearCemetery);
            Quests.Add(clearBasement);
        }

        private static void PopulateLocations()
        {
            // Create each location
            Location home = new Location(LOCATION_ID_HOME, "Home", "Your house. You really need to clean up the place.", "No loot drops here.");

            Location townSquare = new Location(LOCATION_ID_TOWN_SQUARE, "Town square", "You see a fountain.", "No loot drops here.");
            townSquare.QuestAvailableHere = QuestByID(QUEST_ID_CLEAR_GUARD_TOWER);

            Location alchemistHut = new Location(LOCATION_ID_ALCHEMIST_HUT, "Alchemist's hut", "There are many strange plants on the shelves.", "No loot drops here.");
            alchemistHut.QuestAvailableHere = QuestByID(QUEST_ID_CLEAR_ALCHEMIST_GARDEN);

            Location alchemistsGarden = new Location(LOCATION_ID_ALCHEMISTS_GARDEN, "Alchemist's garden", "Many plants are growing here.", "Items that can be found here: rat tail, piece of fur, bucket helmet.");
            alchemistsGarden.MonsterLivingHere = MonsterByID(MONSTER_ID_RAT);

            Location farmhouse = new Location(LOCATION_ID_FARMHOUSE, "Farmhouse", "There is a small farmhouse, with a farmer in front.", "No loot drops here.");
            farmhouse.QuestAvailableHere = QuestByID(QUEST_ID_CLEAR_FARMERS_FIELD);

            Location farmersField = new Location(LOCATION_ID_FARM_FIELD, "Farmer's field", "You see rows of vegetables growing here.", "Items that can be found here: snake fang, snakeskin.");
            farmersField.MonsterLivingHere = MonsterByID(MONSTER_ID_SNAKE);

            Location guardPost = new Location(LOCATION_ID_GUARD_POST, "Guard post", "There is a large, tough-looking guard here.", "Items that can be found here: guard helmet, iron chestplate, club.", ItemByID(ITEM_ID_ADVENTURER_PASS));
            guardPost.MonsterLivingHere = MonsterByID(MONSTER_ID_GUARD);

            Location bridge = new Location(LOCATION_ID_BRIDGE, "Bridge", "A stone bridge crosses a wide river.", "No loot drops here.");

            Location spiderField = new Location(LOCATION_ID_SPIDER_FIELD, "Forest", "You see spider webs covering covering the trees in this forest.", "Loot drops available here: ring of revival, large health potion, large mana potion, iron broadsword.");
            spiderField.MonsterLivingHere = MonsterByID(MONSTER_ID_GIANT_SPIDER);
 
            Location cemetery = new Location(LOCATION_ID_CEMETERY, "Cemetery", "You see rows and rows of gravestones, but the dirt in front of some of them is dug up.", "Loot available here: skull, bone, rusty leggings.");
            cemetery.MonsterLivingHere = MonsterByID(MONSTER_ID_SKELETON);

            Location necromancersHut = new Location(LOCATION_ID_NECROMANCERS_HUT, "The necromancer's hut", "There is an evil-looking old man in the centre of the room.", "No loot drops here.");
            necromancersHut.QuestAvailableHere = QuestByID(QUEST_ID_CLEAR_CEMETERY);

            Location basement = new Location(LOCATION_ID_BASEMENT, "Your basement", "There are rats everywhere, and a hatch to the drain system.", "Loot drops here: rat tail, piece of fur, bucket helmet.");
            basement.QuestAvailableHere = QuestByID(QUEST_ID_CLEAR_BASEMENT);
            basement.MonsterLivingHere = MonsterByID(MONSTER_ID_RAT);

            Location drains = new Location(LOCATION_ID_DRAINS, "The drains under your house.", "There is slime all over the pipes.", "Loot drops here: rat tail, piece of fur, bucket helmet.", ItemByID(ITEM_ID_DRAIN_KEY));

            // Link the locations together
            drains.LocationToNorth = basement;

            basement.LocationToSouth = drains;
            basement.LocationToNorth = home;

            home.LocationToSouth = basement;
            home.LocationToNorth = townSquare;

            townSquare.LocationToNorth = alchemistHut;
            townSquare.LocationToSouth = home;
            townSquare.LocationToEast = guardPost;
            townSquare.LocationToWest = farmhouse;

            farmhouse.LocationToEast = townSquare;
            farmhouse.LocationToWest = farmersField;

            farmersField.LocationToEast = farmhouse;

            alchemistHut.LocationToSouth = townSquare;
            alchemistHut.LocationToNorth = alchemistsGarden;

            alchemistsGarden.LocationToSouth = alchemistHut;

            guardPost.LocationToEast = bridge;
            guardPost.LocationToWest = townSquare;

            bridge.LocationToWest = guardPost;
            bridge.LocationToEast = cemetery;

            cemetery.LocationToWest = bridge;
            cemetery.LocationToNorth = necromancersHut;
            cemetery.LocationToEast = spiderField;

            necromancersHut.LocationToSouth = cemetery;

            spiderField.LocationToWest = cemetery;

            // Add the locations to the static list
            Locations.Add(home);
            Locations.Add(townSquare);
            Locations.Add(guardPost);
            Locations.Add(alchemistHut);
            Locations.Add(alchemistsGarden);
            Locations.Add(farmhouse);
            Locations.Add(farmersField);
            Locations.Add(bridge);
            Locations.Add(spiderField);
            Locations.Add(cemetery);
            Locations.Add(necromancersHut);
            Locations.Add(basement);
            Locations.Add(drains);
        }

        public static Item ItemByID(int id)
        {
            foreach (Item item in Items)
            {
                if (item.ID == id)
                {
                    return item;
                }
            }

            return null;
        }

        public static Monster MonsterByID(int id)
        {
            foreach (Monster monster in Monsters)
            {
                if (monster.ID == id)
                {
                    return monster;
                }
            }

            return null;
        }

        public static Quest QuestByID(int id)
        {
            foreach (Quest quest in Quests)
            {
                if (quest.ID == id)
                {
                    return quest;
                }
            }

            return null;
        }

        public static Location LocationByID(int id)
        {
            foreach (Location location in Locations)
            {
                if (location.ID == id)
                {
                    return location;
                }
            }

            return null;
        }
    }
}